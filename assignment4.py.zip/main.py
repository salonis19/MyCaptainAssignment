'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

# Online Python - IDE, Editor, Compiler, Interpreter


# Python program to print positive Numbers in a list 

# list of numbers
list1 = [12, -7, 5, 64, -14]
list2 = [12, -14, -95, 3]

# iterating each number in list
for num in list1:
    
    # checking condition
    if num >= 0:
        print(num, end = " ")
        
    for num in list2:
        
        #checking condition
        if num >= 0:
            print(num, end = " ")